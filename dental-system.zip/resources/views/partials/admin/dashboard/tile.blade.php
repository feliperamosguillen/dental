<div class="tile is-parent">
    <article class="tile is-child box">
        <p class="title">
            <span class="icon is-large">{!! icon($icon) !!}</span>
            <span>{{ $value }}</span>
        </p>
        <p class="subtitle">{{ __('admin.fields.dashboard.' . $key) }}</p>
    </article>
</div>
