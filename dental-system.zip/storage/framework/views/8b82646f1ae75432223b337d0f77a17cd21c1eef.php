<nav class="navbar is-light">
    <div class="container">
        <div class="navbar-brand">
            <a class="navbar-item" href="<?php echo e(route('root')); ?>">
                <img src="<?php echo e(asset(config('settings.logo'))); ?>" alt="<?php echo e(config('settings.site_title')); ?>">
            </a>
            <div id="toggle-menu" class="navbar-burger burger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
        <div id="menu" class="navbar-menu">
            <div class="navbar-start">
                <?php $__currentLoopData = getMenu(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($p->children->count() > 0): ?>
                        <div class="navbar-item has-dropdown is-hoverable">
                            <div class="navbar-link">
                                <a class="navbar-item <?php echo e(active($p)); ?>" href="<?php echo e($p->link); ?>">
                                    <?php echo e($p->title); ?>

                                </a>
                            </div>
                            <div class="navbar-dropdown">
                                <?php $__currentLoopData = $p->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="navbar-item <?php echo e(active($child)); ?>" href="<?php echo e($child->link); ?>">
                                        <?php echo e($child->title); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <a class="navbar-item" href="<?php echo e($p->link); ?>">
                            <?php echo e($p->title); ?>

                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="navbar-end">
                <div class="navbar-item">
                    <div class="field is-grouped">
                        <p class="control">
                            <a target="_blank" rel="noopener noreferrer" href="<?php echo $__env->yieldContent('facebook'); ?>" class="button button-facebook">
                                <span class="icon"><?php echo icon('facebook'); ?></span>
                                <span><?php echo e(__('app.buttons.share')); ?></span>
                            </a>
                        </p>
                        <p class="control">
                            <a target="_blank" rel="noopener noreferrer" href="<?php echo $__env->yieldContent('twitter'); ?>" class="button button-twitter">
                                <span class="icon"><?php echo icon('twitter'); ?></span>
                                <span><?php echo e(__('app.buttons.tweet')); ?></span>
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/partials/app/nav.blade.php ENDPATH**/ ?>