<section class="hero is-primary <?php echo e($class ?? ''); ?>">
    <div class="hero-body">
        <div class="container">
            <div class="columns">
                <div class="column is-12">
                    <h1 class="title"><?php echo e($title); ?></h1>
                    <h2 class="subtitle"><?php echo e($description); ?></h2>
                </div>
            </div>
        </div>
    </div>
</section>
<?php echo $__env->make('partials.app.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/partials/app/hero.blade.php ENDPATH**/ ?>