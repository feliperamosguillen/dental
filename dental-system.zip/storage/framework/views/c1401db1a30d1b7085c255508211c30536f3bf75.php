<div class="control">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="_method" value="<?php echo e(${$resource} !== null ? 'PUT' : 'POST'); ?>">
    <button type="submit" class="button is-info is-fullwidth is-large"><?php echo e(__('admin.save')); ?></button>
</div>
</form>
</div>
</section>
<?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/partials/admin/form/submit.blade.php ENDPATH**/ ?>