<div class="columns is-multiline">
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="column is-12">
            <div class="columns is-vcentered">
                <div class="column is-9">
                    <h2 class="title"><a class="has-text-grey-dark" href="<?php echo e($article->link); ?>"><?php echo e($article->title); ?></a></h2>
                </div>
                <div class="column is-3 has-text-right-desktop">
                    <a href="<?php echo e($article->category->link); ?>" class="button is-default"><?php echo e($article->category->title); ?></a>
                </div>
            </div>
            <div class="level"></div>
            <div class="content">
                <p><?php echo e(getNWords($article->content, 50)); ?></p>
            </div>
            <div class="columns is-vcentered">
                <div class="column is-9">
                    <a class="button is-link" href="<?php echo e($article->link); ?>"><?php echo e(__('app.read_more')); ?></a>
                </div>
                <div class="column is-3 has-text-right-desktop">
                    <p class="has-text-grey"><?php echo e($article->localized_published_at); ?></p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($articles->total() > $articles->count()): ?>
        <div class="column is-12">
            <?php echo $articles->appends(request()->except('page'))->links(); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/partials/app/articles.blade.php ENDPATH**/ ?>