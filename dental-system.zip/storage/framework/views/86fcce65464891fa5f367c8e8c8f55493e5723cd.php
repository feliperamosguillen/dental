<div class="field">
    <div class="file is-large has-name">
        <label class="file-label">
            <input class="file-input" type="file" name="<?php echo e($attribute); ?>">
            <div class="file-cta">
                <div class="file-icon"><?php echo icon('upload-cloud'); ?></div>
                <div class="file-label"><?php echo e(__('admin.fields.' . $attribute)); ?></div>
            </div>
            <?php if(isset(${$resource}->$attribute)): ?>
                <div class="file-name">
                    <a target="_blank" rel="noopener" href="<?php echo e(asset(${$resource}->$attribute)); ?>"><?php echo e(${$resource}->$attribute); ?></a>
                </div>
            <?php else: ?>
                <div class="file-name is-hidden"></div>
            <?php endif; ?>
        </label>
    </div>
</div>

<?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/partials/admin/form/file.blade.php ENDPATH**/ ?>