<footer class="footer">
    <div class="container">
        <div class="content">
            <div class="columns">
                <div class="column is-3">
                    <p class="title is-5"><?php echo e(__('app.footer.share')); ?></p>
                    <?php $__currentLoopData = ['facebook', 'twitter']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p>
                            <a href="<?php echo $__env->yieldContent($social); ?>" rel="nofollow noopener" target="_blank">
                                <span class="icon"><?php echo icon($social); ?></span>
                                <span class="text"><?php echo e(ucfirst($social)); ?></span>
                            </a>
                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="column is-3">
                    <p class="title is-5"><?php echo e(__('app.footer.latest')); ?></p>
                    <?php $__currentLoopData = getFooterArticles(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><a href="<?php echo e($article->link); ?>"><?php echo e($article->title); ?></a></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="column is-6">
                    <p class="title is-5"><?php echo e(__('app.footer.about')); ?></p>
                    <p><?php echo e(__('app.footer.text')); ?></p>
                    <a href="<?php echo e(__('app.footer.url')); ?>"><?php echo e(__('app.footer.url')); ?></a>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/partials/app/footer.blade.php ENDPATH**/ ?>