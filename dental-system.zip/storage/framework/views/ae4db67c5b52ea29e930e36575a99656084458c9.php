

<?php $__env->startSection('content'); ?>
    <section class="hero is-light is-fullheight">
        <div class="hero-body">
            <div class="container has-text-centered">
                <div class="column is-4 is-offset-4">
                    <h3 class="title has-text-grey">
                        <?php echo e(__('auth.login.submit')); ?>

                    </h3>
                    <div class="box">
                        <figure class="avatar">
                            <img alt="Avatar" src="/i/logo.png" style="width: 50%;">
                        </figure>
                        <form id="login" method="POST" action="<?php echo e(route('auth.login.post')); ?>">
                            <?php echo $__env->make('partials.admin.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="field">
                                <div class="control">
                                    <input class="input is-large" value="<?php echo e(old('email') ?? ''); ?>" type="email" name="email" placeholder="<?php echo e(__('auth.login.email')); ?>" autofocus>
                                </div>
                            </div>
                            <div class="field">
                                <div class="control">
                                    <input class="input is-large" type="password" name="password" placeholder="<?php echo e(__('auth.login.password')); ?>">
                                </div>
                            </div>
                            <?php if($hasCaptcha): ?>
                                <div class="field has-addons has-addons-centered">
                                    <div class="control">
                                        <?php echo NoCaptcha::display(); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="field">
                                <label class="checkbox">
                                    <input type="checkbox" name="remember" value="1" checked> <?php echo e(__('auth.login.remember')); ?>

                                </label>
                            </div>
                            <div class="control">
                                <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />
                                <button type="submit" class="button is-info is-fullwidth is-large"><?php echo e(__('auth.login.submit')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php if($hasCaptcha): ?>
    <?php $__env->startSection('scripts'); ?>
        <?php echo NoCaptcha::renderJs('en'); ?>

    <?php $__env->stopSection(); ?>
<?php endif; ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/auth/login.blade.php ENDPATH**/ ?>