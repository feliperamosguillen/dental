<!DOCTYPE html>
<html lang="en" itemscope itemtype="http://schema.org/WebPage">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="rating" content="general">
    <meta name="robots" content="<?php echo $__env->yieldContent('robots'); ?>">
    <meta property="og:locale" content="en_US">
    <meta property="og:url" content="<?php echo e(request()->url()); ?>">
    <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>">
    <meta property="og:image" content="<?php echo $__env->yieldContent('image'); ?>">
    <meta property="og:type" content="website">
    <meta name="description" property="og:description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="<?php echo $__env->yieldContent('title'); ?>">
    <meta name="twitter:description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="twitter:image" content="<?php echo $__env->yieldContent('image'); ?>">
    <meta name="twitter:url" content="<?php echo e(request()->url()); ?>">
    <meta name="token" content="<?php echo e(csrf_token()); ?>">
    <meta itemprop="name" content="<?php echo $__env->yieldContent('title'); ?>">
    <meta itemprop="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta itemprop="image" content="<?php echo $__env->yieldContent('image'); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('i/icons/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('i/icons/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('i/icons/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('i/icons/site.webmanifest')); ?>">
    <link rel="mask-icon" href="<?php echo e(asset('i/icons/safari-pinned-tab.svg')); ?>" color="#336699">
    <link rel="shortcut icon" href="<?php echo e(asset('i/icons/favicon.ico')); ?>">
    <meta name="msapplication-TileColor" content="#336699">
    <meta name="msapplication-config" content="<?php echo e(asset('i/icons/browserconfig.xml')); ?>">
    <meta name="theme-color" content="#336699">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(mix('dist/css/app.css'))); ?>">
    <?php if (! empty(trim($__env->yieldContent('canonical')))): ?><link rel="canonical" href="<?php echo $__env->yieldContent('canonical'); ?>"><?php endif; ?>
    <script src="<?php echo e(asset(mix('dist/js/app.js'))); ?>"></script>
    <?php if(env('APP_ENV') !== 'local' && config('settings.analytics_id') !== null): ?>
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e(config('settings.analytics_id')); ?>"></script>
        <script>window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}gtag('js', new Date());gtag('config', '<?php echo e(config('settings.analytics_id')); ?>', {'anonymize_ip': true});</script>
    <?php endif; ?>
</head>
<body>
<?php echo $__env->make('partials.app.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('partials.app.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if (! empty(trim($__env->yieldContent('scripts')))): ?><?php echo $__env->yieldContent('scripts'); ?><?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/layouts/app.blade.php ENDPATH**/ ?>