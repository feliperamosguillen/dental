

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="container is-fluid">
            <div class="card no-box-shadow-mobile">
                <header class="card-header">
                    <p class="card-header-title">
                        <?php echo e(__(Route::getCurrentRoute()->getName())); ?>

                        <?php if(isset($link)): ?>
                            <a class="navbar-item" href="<?php echo e($link); ?>">
                                <span class="icon"><?php echo icon('plus'); ?></span>
                            </a>
                        <?php endif; ?>
                    </p>
                </header>
                <div class="card-content" style="padding-bottom: 2rem;"><?php echo $dataTable->table(); ?></div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $dataTable->scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/admin/table.blade.php ENDPATH**/ ?>