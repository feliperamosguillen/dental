<div class="navbar-item <?php echo e($class ?? ''); ?>">
    <form method="POST" action="<?php echo e(route('auth.logout')); ?>">
        <?php echo csrf_field(); ?>
        <p class="field">
            <button type="submit" class="button is-dark">
                <span class="icon"><?php echo icon('log-out'); ?></span>
                <span><?php echo e(__('auth.logout')); ?></span>
            </button>
        </p>
    </form>
</div>
<?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/partials/admin/nav/logout.blade.php ENDPATH**/ ?>