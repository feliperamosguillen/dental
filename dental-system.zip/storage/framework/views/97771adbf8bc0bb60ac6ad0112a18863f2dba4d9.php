<?php if(count($errors) > 0): ?>
    <article class="message is-danger">
        <div class="message-body">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="help is-danger">
                    <span class="icon"><?php echo icon('alert-circle'); ?></span>
                    <span class="text"><?php echo e($error); ?></span>
                </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </article>
<?php endif; ?>
<?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/partials/admin/errors.blade.php ENDPATH**/ ?>