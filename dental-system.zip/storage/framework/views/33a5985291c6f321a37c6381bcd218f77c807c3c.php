												<nav class="navbar is-dark" role="navigation" aria-label="main navigation">
    <div class="container is-fluid">
        <div class="navbar-brand">
            <a class="navbar-item" href="<?php echo e(route('root')); ?>">
                <span class="icon"><?php echo icon('home'); ?></span>
                <span><?php echo e(config('settings.site_title')); ?></span>
            </a>
            <button onclick="document.querySelector('.navbar-menu').classList.toggle('is-active');" class="button is-dark navbar-burger">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
        <div class="navbar-menu">
            <div class="navbar-start">
                <?php echo $__env->make('partials.admin.nav.single', ['link' => route('admin.dashboard.index'), 'text' => __('admin.dashboard.index'), 'icon' => 'target'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.admin.nav.dropdown', ['resource' => 'user', 'icon' => 'users'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!--  Do not remove line NAVIGATION_FLAG if you want to use CMS generator properly -->
                <!-- Check the file app/Console/Commands/Cms/Resource.php -->
				<?php echo $__env->make('partials.admin.nav.dropdown', ['resource' => 'patient', 'icon' => 'more-horizontal'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php echo $__env->make('partials.admin.nav.dropdown', ['resource' => 'doctor', 'icon' => 'more-horizontal'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php echo $__env->make('partials.admin.nav.dropdown', ['resource' => 'schedule', 'icon' => 'more-horizontal'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!--NAVIGATION_FLAG-->
                <?php echo $__env->make('partials.admin.nav.logout', ['class' => 'is-hidden-tablet'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             </div>
        </div>
        <div class="navbar-end is-hidden-mobile">
            <?php echo $__env->make('partials.admin.nav.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/partials/admin/nav.blade.php ENDPATH**/ ?>