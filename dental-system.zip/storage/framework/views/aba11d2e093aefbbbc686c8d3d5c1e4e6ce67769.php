<?php if(isset($errors) && count($errors) > 0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="notification response-notification is-warning has-text-centered">
            <span class="icon"><?php echo icon('alert-circle'); ?></span>
            <span class="text"><?php echo e($error); ?></span>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <div class="notification response-notification is-warning has-text-centered">
        <span class="icon"><?php echo icon('alert-circle'); ?></span>
        <span class="text"><?php echo e(session()->get('error')); ?></span>
    </div>
<?php endif; ?>
<?php if(session()->has('success')): ?>
    <div class="notification response-notification is-success has-text-centered">
        <span class="icon"><?php echo icon('info'); ?></span>
        <span class="text"><?php echo e(session()->get('success')); ?></span>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\night\Documents\pruebas-tecnicas\loyalty\dental-system\resources\views/partials/app/errors.blade.php ENDPATH**/ ?>