<?php

return [
    'analytics_id'     => null,
    'logo'             => 'i/icons/android-chrome-192x192.png',
    'login_image'      => 'https://ssl.gstatic.com/accounts/ui/avatar_2x.png',
    'site_description' => 'System for evaluation.',
    'site_title'       => 'Dental System | Loyalty'
];
